# Nginx越界读取缓存漏洞（CVE-2017-7529）

运行测试环境：

```
docker-compose up -d
```

访问`http://your-ip:8080/`，即可查看到Nginx默认页面，这个页面实际上是反向代理的8081端口的内容。

调用`python3 poc.py http://your-ip:8080/`，读取返回结果：

![](01.jpg)

可见，越界读取到了位于“HTTP返回包体”前的“文件头”、“HTTP返回包头”等内容。

如果读取有误，请调整poc.py中的偏移地址（605）。